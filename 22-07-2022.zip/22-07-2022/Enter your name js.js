let name = prompt("your name");
document.write(name);